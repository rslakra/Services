/**
 * hamburger event handling
 * @type {Element}
 */
var hamburger = document.querySelector(".hamburger .hamburger__inner");
hamburger.addEventListener("click", function () {
    document.querySelector("wrapper").classList.toggle("active");
});

var topNavbar = document.querySelector(".top_navbar .fas");
topNavbar.addEventListener("click", function () {
    document.querySelector("profile_dd").classList.toggle("active");
});


$(document).ready(function () {
    $(".hamburger .hamburger__inner").click(function () {
        $(".wrapper").toggleClass("active")
    })

    $(".top_navbar .fas").click(function () {
        $(".profile_dd").toggleClass("active");
    });
})
