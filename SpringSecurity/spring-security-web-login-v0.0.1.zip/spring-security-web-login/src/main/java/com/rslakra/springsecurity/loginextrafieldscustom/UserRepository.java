package com.rslakra.springsecurity.loginextrafieldscustom;

public interface UserRepository {

    public User findUser(String username, String domain);
    
}
