package com.rslakra.springsecurity.loginextrafieldscustom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityWebLoginApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityWebLoginApplication.class, args);
    }

}
